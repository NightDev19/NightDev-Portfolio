'use server'

import { createAdminClient } from '@/lib/supabase/admin'
import { revalidatePath } from 'next/cache'
import type { BlogPostFormData } from './schemas'

export async function createBlogPost(data: BlogPostFormData) {
  const supabase = createAdminClient()

  const coverImageValue = data.cover_image?.trim() || null

  const insertData = {
    title: data.title,
    slug: data.slug,
    excerpt: data.excerpt || null,
    content: data.content,
    cover_image: coverImageValue,
    tags: data.tags || [],
    published: data.published ?? false,
  }

  console.log('[createBlogPost] cover_image value:', JSON.stringify(coverImageValue))
  console.log('[createBlogPost] full insertData:', JSON.stringify(insertData, null, 2))

  const { data: result, error } = await supabase.from('blog_posts').insert(insertData).select()

  if (error) {
    console.error('[createBlogPost] Error:', error.message)
    return { error: error.message }
  }

  console.log('[createBlogPost] Inserted row:', JSON.stringify(result, null, 2))

  revalidatePath('/blog')
  revalidatePath('/')
  return { success: true }
}

export async function updateBlogPost(id: string, data: Partial<BlogPostFormData>) {
  const supabase = createAdminClient()

  const coverImageValue = data.cover_image?.trim() || null

  const updateData: Record<string, any> = {
    title: data.title,
    slug: data.slug,
    excerpt: data.excerpt || null,
    content: data.content,
    cover_image: coverImageValue,
    tags: data.tags || [],
    published: data.published,
  }

  // Remove undefined fields so we don't overwrite with undefined
  Object.keys(updateData).forEach(key => {
    if (updateData[key] === undefined) delete updateData[key]
  })

  console.log('[updateBlogPost] cover_image value:', JSON.stringify(coverImageValue))
  console.log('[updateBlogPost] full updateData:', JSON.stringify(updateData, null, 2))

  const { data: result, error } = await supabase
    .from('blog_posts')
    .update(updateData)
    .eq('id', id)
    .select()

  if (error) {
    console.error('[updateBlogPost] Error:', error.message)
    return { error: error.message }
  }

  console.log('[updateBlogPost] Updated row:', JSON.stringify(result, null, 2))

  revalidatePath('/blog')
  revalidatePath(`/blog/${data.slug}`)
  revalidatePath('/')
  revalidatePath('/admin/blog')
  return { success: true }
}

export async function deleteBlogPost(id: string) {
  const supabase = createAdminClient()
  const { error } = await supabase.from('blog_posts').delete().eq('id', id)

  if (error) {
    return { error: error.message }
  }

  revalidatePath('/blog')
  revalidatePath('/')
  revalidatePath('/admin/blog')
  return { success: true }
}
