import type { Metadata } from 'next'
import { MotionWrapper } from '@/components/sections/MotionWrapper'
import { SectionHeader } from '@/components/ui/SectionHeader'
import { BlogCard } from '@/components/ui/BlogCard'
import { getPublishedPosts } from '@/features/blog/queries'

export const metadata: Metadata = {
  title: 'Blog',
  description:
    'Technical notes, learning logs, and documentation from Sherwin Jefferson Tajan\'s engineering journey.',
}

export default async function BlogPage() {
  const posts = await getPublishedPosts()

  // Featured post (first/latest) + rest
  const featured = posts[0]
  const rest = posts.slice(1)

  return (
    <div className="pt-20">
      <section className="py-20 px-4">
        <div className="mx-auto max-w-6xl">
          <MotionWrapper>
            <SectionHeader
              title="Developer Journal"
              subtitle="Technical notes, learning logs, and documentation from my engineering journey."
            />
          </MotionWrapper>

          {posts.length === 0 ? (
            <MotionWrapper>
              <p className="text-center text-muted-foreground mt-12 text-lg">
                No blog posts published yet. Check back soon!
              </p>
            </MotionWrapper>
          ) : (
            <>
              {/* Featured post — large card */}
              {featured && (
                <MotionWrapper delay={0.1} className="mt-8">
                  <BlogCard post={featured} featured />
                </MotionWrapper>
              )}

              {/* Rest of posts — grid */}
              {rest.length > 0 && (
                <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                  {rest.map((post, index) => (
                    <MotionWrapper key={post.id} delay={(index + 1) * 0.1}>
                      <BlogCard post={post} />
                    </MotionWrapper>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </section>
    </div>
  )
}
