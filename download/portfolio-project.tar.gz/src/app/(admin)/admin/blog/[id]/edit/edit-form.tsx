'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, ImageIcon, X, Eye, Pen } from 'lucide-react'
import Link from 'next/link'
import ReactMarkdown from 'react-markdown'
import { blogPostSchema, type BlogPostFormData } from '@/features/blog/schemas'
import { updateBlogPost } from '@/features/blog/actions'
import { ImageUploader } from '@/components/ui/ImageUploader'
import { ImageGallery } from '@/components/ui/ImageGallery'
import { toast } from 'sonner'
import type { BlogPost } from '@/features/blog/types'

interface EditBlogPostFormProps {
  post: BlogPost
}

export function EditBlogPostForm({ post }: EditBlogPostFormProps) {
  const router = useRouter()
  const [tagInput, setTagInput] = useState('')
  const [tags, setTags] = useState<string[]>(post.tags || [])
  const [coverImage, setCoverImage] = useState(post.cover_image || '')
  const [showPreview, setShowPreview] = useState(false)

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<BlogPostFormData>({
    resolver: zodResolver(blogPostSchema),
    defaultValues: {
      title: post.title,
      slug: post.slug,
      excerpt: post.excerpt || '',
      content: post.content,
      cover_image: post.cover_image || '',
      tags: post.tags || [],
      published: post.published,
    },
  })

  // Watch form values for preview
  const watchedTitle = watch('title')
  const watchedContent = watch('content')
  const watchedExcerpt = watch('excerpt')

  function addTag() {
    const trimmed = tagInput.trim()
    if (trimmed && !tags.includes(trimmed)) {
      const updated = [...tags, trimmed]
      setTags(updated)
      setValue('tags', updated)
      setTagInput('')
    }
  }

  function removeTag(tag: string) {
    const updated = tags.filter((t) => t !== tag)
    setTags(updated)
    setValue('tags', updated)
  }

  function handleInsertToContent(markdown: string) {
    const textarea = document.getElementById('content') as HTMLTextAreaElement
    if (textarea) {
      const start = textarea.selectionStart
      const end = textarea.selectionEnd
      const currentContent = textarea.value
      const newContent =
        currentContent.substring(0, start) +
        '\n' +
        markdown +
        '\n' +
        currentContent.substring(end)
      setValue('content', newContent, { shouldValidate: true })
    } else {
      const currentVal = document.querySelector<HTMLInputElement>('#content')?.value || ''
      setValue('content', currentVal + '\n' + markdown + '\n', { shouldValidate: true })
    }
    toast.success('Image inserted into content')
  }

  function handleSelectCover(url: string) {
    console.log('[handleSelectCover] Setting cover image to:', url)
    setCoverImage(url)
    setValue('cover_image', url, { shouldDirty: true, shouldValidate: true })
  }

  function handleRemoveCover() {
    setCoverImage('')
    setValue('cover_image', '', { shouldDirty: true, shouldValidate: true })
  }

  async function onSubmit(data: BlogPostFormData) {
    // Build the payload explicitly — don't rely on react-hook-form for cover_image
    const payload = {
      title: data.title,
      slug: data.slug,
      excerpt: data.excerpt || null,
      content: data.content,
      cover_image: coverImage || null,
      tags: tags,
      published: data.published,
    }

    console.log('[onSubmit] Saving cover_image:', payload.cover_image)

    const result = await updateBlogPost(post.id, payload)

    if (result.error) {
      toast.error(result.error)
    } else {
      toast.success('Post updated')
      router.push('/admin/blog')
      router.refresh()
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <Button asChild variant="ghost" size="sm">
          <Link href="/admin/blog">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Link>
        </Button>

        {/* Preview toggle */}
        <div className="flex items-center gap-2 bg-muted rounded-lg p-1">
          <Button
            type="button"
            variant={showPreview ? 'ghost' : 'default'}
            size="sm"
            onClick={() => setShowPreview(false)}
            className="text-xs"
          >
            <Pen className="mr-1.5 h-3.5 w-3.5" />
            Edit
          </Button>
          <Button
            type="button"
            variant={showPreview ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setShowPreview(true)}
            className="text-xs"
          >
            <Eye className="mr-1.5 h-3.5 w-3.5" />
            Preview
          </Button>
        </div>
      </div>

      {showPreview ? (
        /* ========== PREVIEW MODE ========== */
        <Card>
          <CardContent className="p-0">
            <div className="py-12 px-6">
              <div className="mx-auto max-w-3xl">
                <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
                  {watchedTitle || 'Untitled Post'}
                </h1>

                <div className="mt-3 text-sm text-muted-foreground">
                  {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC' })}
                </div>

                {tags.length > 0 && (
                  <div className="mt-4 flex flex-wrap gap-2">
                    {tags.map((tag) => (
                      <span
                        key={tag}
                        className="inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-xs font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                )}

                {/* Cover image preview */}
                {coverImage && (
                  <div className="mt-6 relative w-full aspect-video rounded-lg overflow-hidden bg-muted">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={coverImage}
                      alt="Cover preview"
                      className="object-cover w-full h-full"
                    />
                  </div>
                )}

                {watchedExcerpt && (
                  <p className="mt-6 text-muted-foreground text-lg leading-relaxed italic">
                    {watchedExcerpt}
                  </p>
                )}

                <div className="mt-8 prose prose-neutral dark:prose-invert max-w-none">
                  <ReactMarkdown>{watchedContent || 'No content yet...'}</ReactMarkdown>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        /* ========== EDIT MODE ========== */
        <Card>
          <CardHeader>
            <CardTitle>Edit Blog Post</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              {/* Hidden input to register cover_image with react-hook-form */}
              <input type="hidden" {...register('cover_image')} />

              <div>
                <Label htmlFor="title">Title</Label>
                <Input id="title" {...register('title')} className="mt-1.5" />
                {errors.title && <p className="mt-1 text-sm text-destructive">{errors.title.message}</p>}
              </div>

              <div>
                <Label htmlFor="slug">Slug</Label>
                <Input id="slug" {...register('slug')} className="mt-1.5" />
                {errors.slug && <p className="mt-1 text-sm text-destructive">{errors.slug.message}</p>}
              </div>

              <div>
                <Label htmlFor="excerpt">Excerpt</Label>
                <Textarea id="excerpt" rows={2} {...register('excerpt')} className="mt-1.5" />
              </div>

              {/* Cover Image */}
              <div>
                <Label>Cover Image</Label>
                <div className="mt-1.5 space-y-3">
                  {coverImage ? (
                    <div className="relative rounded-lg overflow-hidden border bg-muted">
                      <div className="relative w-full h-48">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={coverImage}
                          alt="Cover"
                          className="object-cover w-full h-full"
                        />
                      </div>
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={handleRemoveCover}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                      <div className="p-3 bg-muted/50">
                        <p className="text-xs text-muted-foreground truncate">{coverImage}</p>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <ImageGallery
                        onSelectCover={handleSelectCover}
                        onInsertToContent={handleInsertToContent}
                      />
                    </div>
                  )}

                  {/* Always show Browse Images button when image is set so user can change it */}
                  {coverImage && (
                    <div className="flex gap-2">
                      <ImageGallery
                        onSelectCover={handleSelectCover}
                        onInsertToContent={handleInsertToContent}
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Content with image tools */}
              <div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="content">Content (Markdown)</Label>
                  <ImageGallery onInsertToContent={handleInsertToContent} />
                </div>
                <Textarea
                  id="content"
                  rows={15}
                  {...register('content')}
                  className="mt-1.5 font-mono text-sm"
                />
                {errors.content && <p className="mt-1 text-sm text-destructive">{errors.content.message}</p>}
              </div>

              {/* Image Upload Section */}
              <div className="rounded-lg border p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4 text-muted-foreground" />
                  <Label className="text-sm font-medium">Upload Images</Label>
                </div>
                <p className="text-xs text-muted-foreground">
                  Upload images to use in your blog post. After uploading, click &quot;Insert&quot; to add the image to your content, or &quot;Copy URL&quot; to use it elsewhere.
                </p>
                <ImageUploader
                  onInsertToContent={handleInsertToContent}
                  folder="blog"
                />
              </div>

              <div>
                <Label>Tags</Label>
                <div className="flex gap-2 mt-1.5">
                  <Input
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    placeholder="Add tag..."
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                  />
                  <Button type="button" variant="outline" onClick={addTag}>
                    Add
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {tags.map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center gap-1 rounded-full bg-secondary px-3 py-1 text-xs cursor-pointer"
                      onClick={() => removeTag(tag)}
                    >
                      {tag} ×
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Switch id="published" defaultChecked={post.published} onCheckedChange={(v) => setValue('published', v)} />
                <Label htmlFor="published">Published</Label>
              </div>

              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Saving...' : 'Save Changes'}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
