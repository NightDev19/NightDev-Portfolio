'use client'

import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import rehypeRaw from 'rehype-raw'

interface BlogMarkdownProps {
  content: string
}

export function BlogMarkdown({ content }: BlogMarkdownProps) {
  // Fix literal \n in content (from database) to actual newlines
  const normalizedContent = content
    .replace(/\\n/g, '\n')
    .replace(/\r\n/g, '\n')

  return (
    <div className="prose prose-neutral dark:prose-invert max-w-none
      prose-headings:scroll-mt-20
      prose-h1:text-3xl prose-h1:font-bold prose-h1:mt-10 prose-h1:mb-4
      prose-h2:text-2xl prose-h2:font-bold prose-h2:mt-8 prose-h2:mb-3 prose-h2:pb-2 prose-h2:border-b prose-h2:border-border
      prose-h3:text-xl prose-h3:font-semibold prose-h3:mt-6 prose-h3:mb-2
      prose-h4:text-lg prose-h4:font-semibold prose-h4:mt-4 prose-h4:mb-2
      prose-p:text-base prose-p:leading-7 prose-p:mt-4 prose-p:mb-4
      prose-li:text-base prose-li:leading-7
      prose-strong:text-foreground prose-strong:font-semibold
      prose-ul:mt-4 prose-ul:mb-4 prose-ul:pl-6
      prose-ol:mt-4 prose-ol:mb-4 prose-ol:pl-6
      prose-blockquote:mt-6 prose-blockquote:mb-6
      prose-pre:mt-6 prose-pre:mb-6
      prose-table:mt-6 prose-table:mb-6
      prose-th:text-left prose-th:font-semibold
    ">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        rehypePlugins={[rehypeRaw]}
        components={{
          // Custom image rendering with proper styling
          img: ({ src, alt, ...props }) => (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={src}
              alt={alt || ''}
              className="rounded-lg mx-auto"
              loading="lazy"
              {...props}
            />
          ),
          // Custom link rendering
          a: ({ href, children, ...props }) => (
            <a
              href={href}
              target={href?.startsWith('http') ? '_blank' : undefined}
              rel={href?.startsWith('http') ? 'noopener noreferrer' : undefined}
              className="text-primary hover:underline"
              {...props}
            >
              {children}
            </a>
          ),
          // Custom code block rendering
          pre: ({ children, ...props }) => (
            <pre className="rounded-lg border border-border bg-card p-4 overflow-x-auto" {...props}>
              {children}
            </pre>
          ),
          // Inline code
          code: ({ className, children, ...props }) => {
            const isInline = !className
            return isInline ? (
              <code
                className="bg-muted text-primary px-1.5 py-0.5 rounded text-sm font-mono"
                {...props}
              >
                {children}
              </code>
            ) : (
              <code className="text-sm font-mono" {...props}>
                {children}
              </code>
            )
          },
          // Horizontal rule
          hr: () => (
            <hr className="my-8 border-border" />
          ),
        }}
      >
        {normalizedContent}
      </ReactMarkdown>
    </div>
  )
}
