'use client'

import { motion } from 'framer-motion'
import { Calendar, Tag, ArrowUpRight, Clock } from 'lucide-react'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { cardHover } from '@/lib/motion'
import { formatDate } from '@/lib/utils'
import type { BlogPost } from '@/features/blog/types'

interface BlogCardProps {
  post: BlogPost
  featured?: boolean
}

function getReadingTime(content: string): string {
  const words = content.trim().split(/\s+/).length
  const minutes = Math.ceil(words / 200)
  return `${minutes} min`
}

export function BlogCard({ post, featured = false }: BlogCardProps) {
  if (featured) {
    return <FeaturedBlogCard post={post} />
  }

  return (
    <motion.div variants={cardHover} initial="rest" whileHover="hover">
      <Link href={`/blog/${post.slug}`} className="group block h-full">
        <div className="h-full flex flex-col rounded-xl border border-border bg-card overflow-hidden transition-all duration-300 hover:border-primary/40 hover:shadow-lg hover:shadow-primary/5">
          {/* Cover Image */}
          {post.cover_image ? (
            <div className="relative w-full h-44 bg-muted overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={post.cover_image}
                alt={post.title}
                className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card/30% to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          ) : (
            <div className="relative w-full h-32 bg-gradient-to-br from-primary/10 to-primary/5 flex items-center justify-center">
              <span className="text-4xl font-bold text-primary/20">{post.title.charAt(0)}</span>
            </div>
          )}

          {/* Content */}
          <div className="flex flex-1 flex-col p-5">
            {/* Meta */}
            <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
              <div className="flex items-center gap-1">
                <Calendar className="h-3 w-3" />
                <time dateTime={post.created_at}>{formatDate(post.created_at)}</time>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span>{getReadingTime(post.content)}</span>
              </div>
            </div>

            {/* Title */}
            <h3 className="text-lg font-semibold leading-snug group-hover:text-primary transition-colors line-clamp-2 mb-2">
              {post.title}
            </h3>

            {/* Excerpt */}
            {post.excerpt && (
              <p className="text-muted-foreground text-sm leading-relaxed line-clamp-3 mb-4 flex-1">
                {post.excerpt}
              </p>
            )}

            {/* Tags */}
            {post.tags && post.tags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-auto">
                {post.tags.slice(0, 3).map((tag) => (
                  <span key={tag} className="inline-flex items-center gap-1 rounded-md bg-secondary px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
                    <Tag className="h-2.5 w-2.5" />
                    {tag}
                  </span>
                ))}
                {post.tags.length > 3 && (
                  <span className="text-[11px] text-muted-foreground px-1">+{post.tags.length - 3}</span>
                )}
              </div>
            )}
          </div>
        </div>
      </Link>
    </motion.div>
  )
}

function FeaturedBlogCard({ post }: { post: BlogPost }) {
  return (
    <motion.div variants={cardHover} initial="rest" whileHover="hover">
      <Link href={`/blog/${post.slug}`} className="group block">
        <div className="relative rounded-xl border border-border bg-card overflow-hidden transition-all duration-300 hover:border-primary/40 hover:shadow-xl hover:shadow-primary/5">
          <div className="grid md:grid-cols-2 gap-0">
            {/* Cover Image */}
            <div className="relative aspect-[16/10] md:aspect-auto bg-muted overflow-hidden">
              {post.cover_image ? (
                <>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={post.cover_image}
                    alt={post.title}
                    className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent to-card/10%" />
                </>
              ) : (
                <div className="w-full h-full min-h-[240px] bg-gradient-to-br from-primary/15 to-primary/5 flex items-center justify-center">
                  <span className="text-6xl font-bold text-primary/20">{post.title.charAt(0)}</span>
                </div>
              )}
              {/* Featured badge */}
              <div className="absolute top-4 left-4">
                <Badge className="bg-primary text-primary-foreground shadow-lg">
                  Latest
                </Badge>
              </div>
            </div>

            {/* Content */}
            <div className="flex flex-col justify-center p-6 md:p-8">
              {/* Meta */}
              <div className="flex items-center gap-3 text-sm text-muted-foreground mb-4">
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4" />
                  <time dateTime={post.created_at}>{formatDate(post.created_at)}</time>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4" />
                  <span>{getReadingTime(post.content)} read</span>
                </div>
              </div>

              {/* Title */}
              <h2 className="text-2xl font-bold leading-tight group-hover:text-primary transition-colors sm:text-3xl mb-3">
                {post.title}
              </h2>

              {/* Excerpt */}
              {post.excerpt && (
                <p className="text-muted-foreground leading-relaxed mb-5 line-clamp-3">
                  {post.excerpt}
                </p>
              )}

              {/* Tags */}
              {post.tags && post.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mb-5">
                  {post.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs px-3 py-1">
                      <Tag className="h-3 w-3 mr-1.5" />
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}

              {/* Read more */}
              <div className="flex items-center gap-2 text-sm font-medium text-primary group-hover:gap-3 transition-all">
                Read article
                <ArrowUpRight className="h-4 w-4" />
              </div>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  )
}
